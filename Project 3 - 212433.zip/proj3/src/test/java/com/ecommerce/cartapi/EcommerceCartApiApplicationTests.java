package com.ecommerce.cartapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommerceCartApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
