package com.ecommerce.cartapi.repository;

import com.ecommerce.cartapi.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
